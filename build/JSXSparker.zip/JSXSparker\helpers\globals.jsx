// Don't use 'var JSPK' - some engines call this within a non-global scope
// if using var we end up defining this in the wrong scope

if ("undefined" == typeof JSPK) {
    JSPK = {};
}

if (! JSPK.C) {
    JSPK.C = {}; // stash constants here   
}

JSPK.C.DIRNAME_PREFERENCES  = "JSXSparker";
JSPK.C.FILENAME_PREFERENCES = "JSXSparkerPreferences.json";

JSPK.C.LOG_NONE                      = 0;
JSPK.C.LOG_ERROR                     = 1;
JSPK.C.LOG_WARN                      = 2;
JSPK.C.LOG_NOTE                      = 3;
JSPK.C.LOG_TRACE                     = 4;

/* Add any global constants */
