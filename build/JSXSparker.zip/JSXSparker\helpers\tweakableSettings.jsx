//
// Tweakable Settings
//

// Don't use 'var JSPK' - some engines call this within a non-global scope
// if using var we end up defining this in the wrong scope

if ("undefined" == typeof JSPK) {
    JSPK = {};
}

if (! JSPK.S) {
    JSPK.S = {}; // stash global settings here
}

JSPK.S.LOG_LEVEL                     = JSPK.C.LOG_NONE;

JSPK.S.LOG_TO_ESTK_CONSOLE           = false;
JSPK.S.LOG_TO_FILEPATH               = undefined; // file path or undefined
JSPK.S.LOG_ENTRY_EXIT                = false;

/* Add any global settings, defaults... here */
