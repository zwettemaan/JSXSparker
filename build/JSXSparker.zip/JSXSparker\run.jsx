//@target InDesign

//@include "helpers/runtime.jsx"

main();

function main() {
	
	JSPK.initScript();

	// Your code here...
	alert("Hello World");

}
