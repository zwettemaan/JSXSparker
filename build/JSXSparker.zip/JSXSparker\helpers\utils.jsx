// Don't use 'var JSPK' - some engines call this within a non-global scope
// if using var we end up defining this in the wrong scope

if ("undefined" == typeof JSPK) {
    JSPK = {};
}

JSPK.shallowClone = function shallowClone(obj) 
{

    var retVal = {};
    for (var x in obj) 
    {
        retVal[x] = obj[x];
    }

    return retVal;
}

JSPK.deepClone = function deepClone(obj) 
{

    var retVal;
    if (obj instanceof Array) {
        retVal = [];
    }
    else {
        retVal = {};        
    }
    for (var x in obj) 
    {
        var val = obj[x];
        if (typeof val == "object")
        {
            retVal[x] = JSPK.deepClone(val);
        }
        else
        {
            retVal[x] = val;
        }
    }

    return retVal;
}

// dQ: Wrap a string in double quotes
JSPK.dQ = function(s) {
    return '"' + s.replace(/\\/g,"\\\\").replace(/"/g,'\\"').replace(/\n/g,"\\n").replace(/\r/g,"\\r") + '"';
}

// sQ: Wrap a string in single quotes
JSPK.sQ = function(s) {
    return "'" + s.replace(/\\/g,"\\\\").replace(/'/g,"\\'").replace(/\n/g,"\\n").replace(/\r/g,"\\r") + "'";
}

JSPK.logEntry = function(reportingFunctionArguments) {
    if (JSPK.S.LOG_ENTRY_EXIT) {
        JSPK.logTrace(reportingFunctionArguments, "Entry");
    }
}

JSPK.logExit = function(reportingFunctionArguments) {
    if (JSPK.S.LOG_ENTRY_EXIT) {
        JSPK.logTrace(reportingFunctionArguments, "Exit");
    }
}

JSPK.logError = function(reportingFunctionArguments, s) {
    if (JSPK.S.LOG_LEVEL >= JSPK.C.LOG_ERROR) {
        if (! s) {
            s = reportingFunctionArguments;
            reportingFunctionArguments = undefined;
        }
        JSPK.logMessage(reportingFunctionArguments, "ERROR  : " + s);
    }
}

JSPK.logWarning = function(reportingFunctionArguments, s) {
    if (JSPK.S.LOG_LEVEL >= JSPK.C.LOG_WARN) {
        if (! s) {
            s = reportingFunctionArguments;
            reportingFunctionArguments = undefined;
        }
        JSPK.logMessage(reportingFunctionArguments, "WARNING: " + s);
    }
}

JSPK.logNote = function(reportingFunctionArguments, s) {
    if (JSPK.S.LOG_LEVEL >= JSPK.C.LOG_NOTE) {
        if (! s) {
            s = reportingFunctionArguments;
            reportingFunctionArguments = undefined;
        }
        JSPK.logMessage(reportingFunctionArguments, "NOTE   : " + s);
    }
}

JSPK.logTrace = function(reportingFunctionArguments, s) {
    if (JSPK.S.LOG_LEVEL >= JSPK.C.LOG_TRACE) {
        if (! s) {
            s = reportingFunctionArguments;
            reportingFunctionArguments = undefined;
        }
        JSPK.logMessage(reportingFunctionArguments, "TRACE  : " + s);
    }
}

JSPK.checkMac = function checkMac() {
    

    var retVal = $.os.substr(0,3) == "Mac";


    return retVal;
};

JSPK.logMessage = function(reportingFunctionArguments, message) {

    var savedInLogger = JSPK.inLogger;

    do {
        try {

            if (JSPK.inLogger) {
                break;
            }
            
            JSPK.inLogger = true;
            
            var prefix = "";

            if (! message) {

                  message = reportingFunctionArguments;
                  reportingFunctionArguments = undefined;

            }
            else if (reportingFunctionArguments) {

                if ("string" == typeof reportingFunctionArguments) {

                    prefix += reportingFunctionArguments + ": ";
                    
                }
                else {

                    var reportingFunctionName;
                    try {
                        reportingFunctionName = reportingFunctionArguments.callee.toString().match(/function ([^\(]+)/)[1];
                    }
                    catch (err) {
                        reportingFunctionName = "[anonymous function]";
                    }
                    prefix += reportingFunctionName + ": ";

                }
            }
            
            var estkLogLine = prefix + message;
                    
            if (JSPK.S.LOG_TO_ESTK_CONSOLE) {
                $.writeln(estkLogLine); 
            }

        }
        catch (err) {
        }
    }
    while (false);

    JSPK.inLogger = savedInLogger;
}
