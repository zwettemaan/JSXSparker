var dreamweaver;
var app;

var JSPK;
if (! JSPK) {
    JSPK = {};
}

JSPK.LOG_CRITICAL_ERRORS = false;

JSPK.relativeFilePathsToLoad = [
		"helpers/json2.jsx",
		"helpers/globals.jsx",
		"helpers/tweakableSettings.jsx",
		"helpers/utils.jsx",
		"helpers/pathUtils.jsx",
		"helpers/init.jsx"
];

JSPK.errorBeforeLoggingAvailable = function(error) {

	if (JSPK.logError) {
		JSPK.logError(error);
	}
	else if (JSPK.LOG_CRITICAL_ERRORS) {

		try {

			var f = File(Folder.desktop + "/criticalErrors.log");
			f.open("a");
			f.writeln(error);
			f.close();

		}
		catch (err) {

			try {
				console.log(error);
			}
			catch (err) {	
			}

		}
	}
}

if (dreamweaver) {

	JSPK.loadScript = function(extensionDir, scriptPath) {
		try {
			var fullPath = extensionDir + scriptPath;
			var script = DWfile.read(fullPath);
			eval(script);
		}
		catch (err) {			
			JSPK.errorBeforeLoggingAvailable("hostscript.jsx loadScript throws " + err + " for " + fullPath);	
		}
	}

}
else {

	JSPK.loadScript = function(extensionDir, scriptPath) {
		try {
			var fullPath = extensionDir + scriptPath;
			var file = File(fullPath);
			file.open("r");
			var script = file.read();
			file.close();
			eval(script);
		}
		catch (err) {			
			JSPK.errorBeforeLoggingAvailable("hostscript.jsx loadScript throws " + err + " for " + fullPath);	
		}
	}

}

JSPK.initScript = function initScript(extensionDir) {

	for (var idx = 0; idx < JSPK.relativeFilePathsToLoad.length; idx++) {
		var filePath = JSPK.relativeFilePathsToLoad[idx];
		JSPK.loadScript(extensionDir, filePath);
	}

}

