// Don't use 'var JSPK' - some engines call this within a non-global scope
// if using var we end up defining this in the wrong scope

if ("undefined" == typeof JSPK) {
    JSPK = {};
}

if (! JSPK.path) {
	JSPK.path = {};
}

JSPK.path.basename = function basename(filepath, separator) {
    

    if (! separator) {
        separator = JSPK.path.SEPARATOR;
    }

    // toString() handles cases where filepath is an ExtendScript File/Folder object
    var splitPath = filepath.toString().split(separator);
    do {
        var endSegment = splitPath.pop();   
    }
    while (splitPath.length > 0 && endSegment == "");


    return endSegment;
};

JSPK.path.dirname = function dirname(filepath, separator) {
    

    if (! separator) {
        separator = JSPK.path.SEPARATOR;
    }

    // toString() handles cases where filepath is an ExtendScript File/Folder object
    var splitPath = filepath.toString().split(separator);
    do {
        var endSegment = splitPath.pop();   
    }
    while (splitPath.length > 0 && endSegment == "");

    var retVal = splitPath.join(separator);


    return retVal;
};

JSPK.path.filenameExtension = function filenameExtension(filepath, separator) {
    

    var splitName = JSPK.path.basename(filepath).split(".");
    var extension = "";
    if (splitName.length > 1) {
        extension = splitName.pop();
    }

    var retVal = extension.toLowerCase();


    return retVal;
};

JSPK.path.exists = function exists(filepath) {

    var f = File(filepath);
    var retVal = f.exists;

    return retVal;
};

JSPK.path.isDir = function isDir(filepath) {
    
    // This casts to a File instead of a Folder if the
    // path references a file

    var folder = Folder(folderPath);

    var retVal = (folder instanceof Folder);

    return retVal;
};

JSPK.path.mkdir = function mkdir(folderPath, separator) {

    var success = false;

    do {
        try {
            if (! folderPath) {
                JSPK.logError(arguments, "no folderPath");
                break;
            }

            if (JSPK.path.exists(folderPath)) {
                success = true;
                break;
            }

            var parentFolderPath = JSPK.path.dirname(folderPath, separator);
            success = JSPK.path.mkdir(parentFolderPath, separator);
            if (! success) {
                JSPK.logError(arguments, "cannot create parent folder");
                break;
            }

            var folder = Folder(folderPath);
            folder.create();
            success = folder.exists;
        }
        catch (err) {
            JSPK.logError(arguments, "throws" + err);       
        }
    }
    while (false);

    return success;
};
