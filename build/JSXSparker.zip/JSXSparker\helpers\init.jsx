// Don't use 'var JSPK' - some engines call this within a non-global scope
// if using var we end up defining this in the wrong scope

if ("undefined" == typeof JSPK) {
    JSPK = {};
}

if (JSPK.checkMac()) {
    JSPK.path.SEPARATOR = "/";
    JSPK.isMac = true;
    JSPK.isWindows = false;
}
else {
    JSPK.path.SEPARATOR = "\\";
    JSPK.isMac = false;
    JSPK.isWindows = true;
}

if (! JSPK.dirs) {
    JSPK.dirs = {};
}

